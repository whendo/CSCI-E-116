######################################################################################################
# H13b. Dynamic Model Averaging
# By William Yu, UCLA Anderson Forecast
# 4/16/2024
# Reference: https://www.jstatsoft.org/article/view/v084i11
# https://cran.r-project.org/web/packages/eDMA/eDMA.pdf
###################################################################################################### 
library("eDMA")

## This code reproduces the results of
## Catania and Nonejad:
## 'Dynamic Model Averaging for Practitioners in Economics and Finance:
## The eDMA Package'.
## The structure follows the related article. It is divided in
## sections. The sections can be executed independently, however, the
## initial part of the code 'Starting' has to be always executed.  The
## script reproduces the table as well as the figures of the paper.

#############################################
##               Starting
#############################################
## Path where all the results are saved
sDir <- "./"

## Number of cores
## The number of cores affects the output of Section 5. Computational challenges
## The number of cores is bounded for some part of the analysis where the required
## computational power is low hence controlling for parallel efficiency.
iNcores <- 8

###########################################################
##           The Model : Section 2 Framework          
###########################################################
data("USRecessions", package = "eDMA")
iBurnPeriod = 32
vBurnIn = 1:iBurnPeriod
rgb = c("#D33F6A4D", "#E2E2E24D", "#4A6FE34D", "#6969694D")

data("USData", package = "eDMA")
dim(USData)
head(round(USData[, 1:6], 2))

AR2_formula = GDPDEF ~ Lag(GDPDEF, 1) + Lag(GDPDEF, 2)
AR2_Reg_formula = GDPDEF ~ Lag(GDPDEF, 1) + Lag(GDPDEF, 2)  + Lag(UNEMP, 1)

## Recursive/Rolling OLS
iT = nrow(USData)

## we write iBurnPeriod + 2 due to the fact that we use two lag of GDPDEF
lFit_AR2 = lapply((iBurnPeriod + 2):iT,
                   function(i, formula, data) lm(formula, data = data[1:i]),
                   data = USData, formula = AR2_formula)

lFit_AR2_Reg = lapply((iBurnPeriod + 2):iT,
                       function(i, formula, data) lm(formula, data = data[1:i]),
                       data = USData, formula = AR2_Reg_formula)

## (a) Inflation rate
vGDPDEF = USData[(iBurnPeriod + 2):iT, "GDPDEF"]

## Figure 1 (a)
vDates = as.Date(index(vGDPDEF))
plot(vDates, vGDPDEF, type = "n",  xaxt = "n",  xlab = "", ylab = "", ylim = c(-1.5, 4.0), 
     main="U.S. Quarterly Inflation Rate (%)", las = 1, cex.axis = 0.8)
grid(nx = 10, ny = 10, col = "gray", lty = "dotted")
lines(vDates, vGDPDEF, lwd = 2)
xblocks(USRecessions == 1, col = rgb[4])
axis.Date(1, at = seq(min(vDates), max(vDates), "year"), cex.axis = 0.7)
axis.Date(1, at = seq(min(vDates), max(vDates), "quarter"), labels = FALSE, tcl = -0.2)

## (b) Sum of AR2 coefficients of inflation
vSumCoef = sapply(lFit_AR2, function(x) sum(coef(x)[2:3]))

## Figure 1 (b)
plot(vDates, vSumCoef, type = "n", xaxt = "n", xlab = "", ylab = "", ylim = c(0.8, 1.1),
     main="Inflation Persistence Estimates from AR(2) Model", las = 1, cex.axis = 0.8)
grid(nx = 10, ny = 10, col = "gray", lty = "dotted")
lines(vDates, vSumCoef, lwd = 2)
xblocks(USRecessions == 1, col = rgb[4])
axis.Date(1, at = seq(min(vDates), max(vDates), "year"), cex.axis = 0.7)
axis.Date(1, at = seq(min(vDates), max(vDates), "quarter"), labels = FALSE, tcl = -0.2)

## (c) Recursive beta estimate of unemployment for an AR(2)-unemployment model
vBetaUnemp = sapply(lFit_AR2_Reg, function(x) coef(x)[4])

## Figure 1 (c)
plot(vDates, vBetaUnemp, type = "n", xaxt = "n", xlab = "", ylab = "", ylim = c(-0.5, 0.0),
     main="Recursive OLS Estimates for Beta on Unemployment", las = 1, cex.axis = 0.8)
grid(nx = 10, ny = 10, col = "gray", lty = "dotted")
lines(vDates, vBetaUnemp, lwd = 2)
xblocks(USRecessions == 1, col = rgb[4])
axis.Date(1, at = seq(min(vDates), max(vDates), "year"), cex.axis = 0.7)
axis.Date(1, at = seq(min(vDates), max(vDates), "quarter"), labels = FALSE, tcl = -0.2)

## (d) recursive pval t-test H0 : beta_unemployment = 0
vPval = sapply(lFit_AR2_Reg, function(x) summary(x)$coefficients[4, "Pr(>|t|)"] )

## Figure 1 (d)
plot(vDates, vPval, type = "n", xaxt = "n", xlab = "", ylab = "",
     main="Recursive p value for the Null Hypothesis of Beta=0", las = 1, cex.axis = 0.8)
grid(nx = 10, ny = 10, col = "gray", lty = "dotted")
lines(vDates, vPval, lwd = 2)
xblocks(USRecessions == 1, col = rgb[4])
axis.Date(1, at = seq(min(vDates), max(vDates), "year"), cex.axis = 0.7)
axis.Date(1, at = seq(min(vDates), max(vDates), "quarter"), labels = FALSE, tcl = -0.2)

#############################################
##           Simulations : Section 4.1       
#############################################
set.seed(7892)
iT = 500
iK = 3
dV = 0.1                      # Measurement equation variance
mW = diag(iK + 1) * 0.01      # Covariance matrix in transition equation
dPhi = 1                      # Coefficient in transition equation, random walk 
vBeta0 = rep(0, iK + 1)
mX = cbind(1, matrix(rnorm(iT * (iK)), iT, iK))
lOut = SimulateDLM(iT, mX, vBeta0, mW, dV, dPhi)
vY = lOut$vY
mX = mX[, -1]
iK_Add = 2
mX_add = matrix(rnorm(iT * iK_Add), iT, iK_Add)
SimData = cbind(y = vY, mX, mX_add)
colnames(SimData) = c("y", paste("x", 2:(iK + iK_Add + 1), sep = ""))

## Alternatively: data("SimData", package = "eDMA")

# vDelta: forgetting factor
Fit = DMA(y ~ x2 + x3 + x4 + x5 + x6, data = SimData, vDelta = seq(0.9, 1, 0.01))
Fit

# posterior inclusion probabilities of the predictors
PostProb = as.data.frame(Fit, which = "mincpmt", iBurnPeriod = 50) 
round(tail(PostProb), 2)

if (interactive()) {
   plot(Fit)
}	
plot(Fit, which = "mincpmt", iBurnPeriod = 50)

#############################################
##     Empirical Application : Section 6     
#############################################
data("USData", package = "eDMA")
head(round(USData[, 1:6], 2))

##############################################
##   Estimation Example       
##############################################
## do DMA, keep the first three predictors fixed and the intercept
Fit01 = DMA(GDPDEF ~ Lag(GDPDEF, 1) + Lag(GDPDEF, 2) + Lag(GDPDEF, 3) +
             Lag(ROUTP, 1) + Lag(UNEMP, 1), data = USData, vDelta = c(0.9,0.95,0.99),
           vKeep = c(1, 2, 3, 4))
Fit01
summary(Fit01, iBurnPeriod = 32)

# E[theta_t] SD[theta_t] --> mean and standard deviation across the sample period of the estimates
# E[P(theta_t)] SD[P(theta_t)]  --> posterior probability after burn-in.

InclusionProb = inclusion.prob(Fit01, iBurnPeriod = 32)
tail(round(InclusionProb, 2))

mTheta = coef(Fit01, iBurnPeriod = 32)

plot(Fit01, which = "vdeltahat", iBurnPeriod = 32) # posterior weighted average of delta

# posterior probability of the forgetting factors
InclusionProbDelta = as.data.frame(Fit01, which = "mpmt", iBurnPeriod = 32) 
round(tail(InclusionProbDelta), 2)
# number of predictors in the model with the highest posterior model probability
plot(Fit01, which = "vsize_DMS", iBurnPeriod = 32)

Fit02 = DMA(GDPDEF ~ Lag(GDPDEF, 1) + Lag(GDPDEF, 2) + Lag(GDPDEF, 3) +
            Lag(ROUTP, 1) + Lag(UNEMP, 1), data = USData, vDelta = c(0.9,0.94,0.96,0.98,0.99),
          vKeep = 1)
Fit02
summary(Fit02, iBurnPeriod = 32)

InclusionProb = inclusion.prob(Fit02, iBurnPeriod = 32)
tail(round(InclusionProb, 2))

mTheta = coef(Fit02, iBurnPeriod = 32)

plot(Fit02, which = "vdeltahat", iBurnPeriod = 32)

InclusionProbDelta = as.data.frame(Fit02, which = "mpmt", iBurnPeriod = 32)
round(tail(InclusionProbDelta), 2)
plot(Fit02, which = "vsize_DMS", iBurnPeriod = 32)

###########################################################
##   Section 6.2     
###########################################################
Fit = DMA(GDPDEF ~ Lag(GDPDEF, 1) + Lag(GDPDEF, 2) +
               Lag(GDPDEF, 3) + Lag(GDPDEF, 4) +
               Lag(ROUTP, 1) + Lag(RCONS, 1) +
               Lag(RINVR, 1) + Lag(PIMP, 1) +
               Lag(UNEMP, 1) + Lag(NFPR, 1) +
               Lag(HSTS, 1) + Lag(M2, 1) +
               Lag(OIL, 1) + Lag(RAW, 1) +
               Lag(FOOD, 1) + Lag(YL, 1) +
               Lag(TS, 1) + Lag(CS, 1) +
               Lag(MS, 1), data = USData,
           vDelta = c(0.90, 0.92, 0.94, 0.96, 0.98, 0.99, 1.00), vKeep = 1,
           dBeta = 0.96, dAlpha = 0.99)
Fit
summary(Fit, iBurnPeriod = 32)

##############################################
##   Section 6.3       
##############################################
InclusionProb = inclusion.prob(Fit, iBurnPeriod = 32)
tail(round(InclusionProb, 2))

mTheta = coef(Fit, iBurnPeriod = 32)

plot(Fit, which = "vdeltahat", iBurnPeriod = 32)
InclusionProbDelta = as.data.frame(Fit, which = "mpmt", iBurnPeriod = 32)
round(tail(InclusionProbDelta), 2)
plot(Fit, which = "vsize_DMS", iBurnPeriod = 32)

##############################################
##   Section 6.4 Out-of-sample forecasts       
##############################################
# Plain AR(4) Model
Fit_M0 = DMA(GDPDEF ~ Lag(GDPDEF, 1) + Lag(GDPDEF, 2) +
                  Lag(GDPDEF, 3) + Lag(GDPDEF, 4),
              data = USData, vDelta = 1.00,
              dAlpha = 1.00, vKeep = c(1, 2, 3, 4, 5),
              dBeta = 1.0)
summary(Fit_M0, iBurnPeriod = 32)

##############################################
##   Section 6.5       
##############################################
# log-predictive likelihoods (log PLD)
vPL_M0 = pred.like(Fit_M0, iBurnPeriod = 32)
vPL_M3 = pred.like(Fit, iBurnPeriod = 32)
vPLD_M3.M0 = cumsum(vPL_M3 - vPL_M0)
plot(vPLD_M3.M0)

##############################################
##   Section 6: Additional Models
##############################################
## h = 1  # One quarter ahead forecast
AR4_formula = GDPDEF ~ Lag(GDPDEF, 1) + Lag(GDPDEF, 2) + Lag(GDPDEF, 3) + Lag(GDPDEF, 4)

AR4_Reg_formula = GDPDEF ~ Lag(GDPDEF, 1) + Lag(GDPDEF, 2) + Lag(GDPDEF, 3) + Lag(GDPDEF, 4) +
  Lag(ROUTP, 1) + Lag(RCONS, 1) + Lag(RINVR, 1) + Lag(PIMP, 1) + Lag(UNEMP, 1) + Lag(NFPR, 1) +
  Lag(HSTS, 1) + Lag(M2, 1) + Lag(OIL, 1) + Lag(RAW, 1) + Lag(FOOD, 1) + Lag(YL, 1) +
  Lag(TS, 1) + Lag(CS, 1) + Lag(MS, 1)

vDelta = seq(0.9, 1, 0.01)
dBeta = 0.96

# Plain AR(4) model
Model0 = DMA(AR4_formula, data = USData, vDelta = 1, dAlpha = 1, vKeep = c(1, 2, 3, 4, 5), 
             bZellnerPrior = FALSE, dG = 100, dBeta = 1.0)

# Time-varying AR(4) model
Model1 = DMA(AR4_formula, data = USData, vDelta = vDelta, dAlpha = 0.99, vKeep = c(1, 2, 3, 4, 5), 
             bZellnerPrior = FALSE, dG = 100, dBeta = dBeta)

# DMA using AR(4)
Model2 = DMA(AR4_formula, data = USData, vDelta = vDelta, dAlpha = 0.99, vKeep = c(1), 
             bZellnerPrior = FALSE, dG = 100, dBeta = dBeta)

# DMA using AR(4) and exoegous variables
Model3_4 = DMA(AR4_Reg_formula, data = USData, vDelta = vDelta, dAlpha = 0.99, vKeep = c(1), 
               bZellnerPrior = FALSE, dG = 100, dBeta = dBeta)

# Bayesian model averaging (BMA) Bayesian model selection (BMS)
Model5_6 = DMA(AR4_Reg_formula, data = USData, vDelta = 1, dAlpha = 1, vKeep = c(1), 
               bZellnerPrior = FALSE, dG = 100, dBeta = 1.0)

# Kitchen sink model: All variables are included
Model7 = DMA(AR4_Reg_formula, data = USData, vDelta = vDelta, dAlpha = 0.99, vKeep = "KS", 
             bZellnerPrior = FALSE, dG = 100, dBeta = dBeta)

## h = 5  # Five quarter ahead forecast

AR4_formula = GDPDEF ~ Lag(GDPDEF, 5) + Lag(GDPDEF, 6) + Lag(GDPDEF, 7) + Lag(GDPDEF, 8)

AR4_Reg_formula = GDPDEF ~ Lag(GDPDEF, 5) + Lag(GDPDEF, 6) + Lag(GDPDEF, 7) + Lag(GDPDEF, 8) +
  Lag(ROUTP, 5) + Lag(RCONS, 5) + Lag(RINVR, 5) + Lag(PIMP, 5) +
  Lag(UNEMP, 5) + Lag(NFPR, 1) + Lag(HSTS, 5) + Lag(M2, 5) + Lag(OIL, 5) +
  Lag(RAW, 5) + Lag(FOOD, 5) + Lag(YL, 5) + Lag(TS, 5) + Lag(CS, 5) + Lag(MS, 5)

vDelta = seq(0.9, 1, 0.01)

Model0 = DMA(AR4_formula, data = USData, vDelta = 1, dAlpha = 1, vKeep = c(1, 2, 3, 4, 5), 
             bZellnerPrior = FALSE, dG = 100, dBeta = 1.0)
summary(Model0, iBurnPeriod = 32)

Model1 = DMA(AR4_formula, data = USData, vDelta = vDelta, dAlpha = 0.99, vKeep = c(1, 2, 3, 4, 5), 
             bZellnerPrior = FALSE, dG = 100, dBeta = dBeta)
summary(Model1, iBurnPeriod = 32)

Model2 = DMA(AR4_formula, data = USData, vDelta = vDelta, dAlpha = 0.99, vKeep = c(1), 
             bZellnerPrior = FALSE, dG = 100, dBeta = dBeta)
summary(Model2, iBurnPeriod = 32)

Model3_4 = DMA(AR4_Reg_formula, data = USData, vDelta = vDelta, dAlpha = 0.99, vKeep = c(1), 
               bZellnerPrior = FALSE, dG = 100, dBeta = dBeta)
summary(Model3_4, iBurnPeriod = 32)

Model5_6 = DMA(AR4_Reg_formula, data = USData, vDelta = 1, dAlpha = 1, vKeep = c(1), 
               bZellnerPrior = FALSE, dG = 100, dBeta = 1.0)
summary(Model5_6, iBurnPeriod = 32)

Model7 = DMA(AR4_Reg_formula, data = USData, vDelta = vDelta, dAlpha = 0.99, vKeep = "KS", 
             bZellnerPrior = FALSE, dG = 100, dBeta = dBeta)
summary(Model7, iBurnPeriod = 32)
