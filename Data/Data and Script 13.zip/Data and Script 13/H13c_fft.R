######################################################################################################
# H13c. Fourier Transform
# By William Yu, UCLA Anderson Forecast
# updated on 12/3/2024
# Reference: https://www.sciencedirect.com/topics/engineering/fourier-transform
# https://betterexplained.com/articles/an-interactive-guide-to-the-fourier-transform/
# https://scholar.harvard.edu/files/schwartz/files/lecture8-fouriertransforms.pdf
######################################################################################################
library(ggplot2)

# Define the range for the angle (theta) in radians
theta = seq(0, 2 * pi, length.out = 500)

# Euler's formula: e^(i*theta) = cos(theta) + i*sin(theta)
cos_part = cos(theta)  # Real part
sin_part = sin(theta)  # Imaginary part

# Create a data frame for visualization
euler_data = data.frame(
  Theta = theta,
  Real = cos_part,       # Cosine component
  Imaginary = sin_part,  # Sine component
  Magnitude = sqrt(cos_part^2 + sin_part^2)  # Magnitude, which is always 1
)

# Plot Real (cosine) and Imaginary (sine) components
ggplot(euler_data, aes(x = Theta)) +
  geom_line(aes(y = Real, color = "Real (cos(theta))"), size = 1) +
  geom_line(aes(y = Imaginary, color = "Imaginary (sin(theta))"), size = 1) +
  geom_hline(yintercept = 0, color = "black", linetype = "dashed") +
  labs(
    title = "Euler's Formula Visualization",
    subtitle = expression(e^{i*theta} == cos(theta) + i*sin(theta)),
    x = "Theta (radians)",
    y = "Value"
  ) +
  scale_color_manual(
    values = c("Real (cos(theta))" = "blue", "Imaginary (sin(theta))" = "green"),
    name = "Components"
  ) +
  theme_minimal() +
  theme(legend.position = "bottom")

################################################################################
# Simulation
################################################################################
time = seq(0, 2 * pi, length.out = 500) # Time from 0 to 2*pi
wave1 = 0.8 * sin(time)                 # Low-frequency sine wave. 1 cycle in the sample period
wave2 = 0.1 * cos(2 * time)             # Cosine wave. 2 cycles in the sample period
wave3 = 0.05 * sin(3 * time)            # Sine wave. 3 cycles in the sample period
wave4 = 0.05 * cos(4 * time)            # High-frequency cosine wave. 4 cycles.

# Combine waves into a complex signal
complex_signal = wave1 + wave2 + wave3 + wave4

# Create a data frame for visualization
data = data.frame(
  Time = rep(time, 5),
  Amplitude = c(wave1, wave2, wave3, wave4, complex_signal),
  Signal = rep(c("Wave 1: 0.8*sin(t)", "Wave 2: 0.1*cos(2t)",
                 "Wave 3: 0.05*sin(3t)", "Wave 4: 0.05*cos(4t)", "Combined Signal"), each = length(time))
)

# Plot individual waves and combined signal
ggplot(data, aes(x = Time, y = Amplitude, color = Signal)) +
  geom_line(size = 1) +
  facet_wrap(~Signal, ncol = 1, scales = "free_y") +
  theme_minimal() +
  labs(title = "Simulated Waves and Combined Signal",
       x = "Time",
       y = "Amplitude")

# Perform Fourier Transform
fft_result = fft(complex_signal)
fft_magnitude = Mod(fft_result)       # Get magnitude of frequencies
fft_frequency = seq(0, length(fft_magnitude) - 1) / (2 * pi) # Frequency bins

# Create data frame for FFT plot
fft_data = data.frame(
  Frequency = fft_frequency[1:(length(fft_frequency) / 2)], # Only positive frequencies
  Magnitude = fft_magnitude[1:(length(fft_magnitude) / 2)]  # Corresponding magnitudes
)

# Plot Fourier Transform results
ggplot(fft_data, aes(x = Frequency, y = Magnitude)) +
  geom_line(color = "blue", size = 1) +
  theme_minimal() +
  labs(title = "Frequency Spectrum (Fourier Transform)",
       x = "Frequency",
       y = "Magnitude") +
  scale_x_continuous(limits = c(0, 1)) # Focus on relevant frequency range --> 1/0.159 = 6.29



