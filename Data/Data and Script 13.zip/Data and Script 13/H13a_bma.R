######################################################################################################
# H13a. Bayesian Model Averaging
# By William Yu, UCLA Anderson Forecast
# updated on 11/19/2024
# Reference: http://bms.zeugner.eu/tutorials/bms.pdf
######################################################################################################
library(MASS)
?Boston
Boston=Boston

##################################################
# Linear model
##################################################
fit = lm(medv~., data=Boston)
summary(fit)

library(leaps)
fit01=regsubsets(medv~., data=Boston)
reg01=summary(fit01)
which.max(reg01$adjr2)
which.min(reg01$cp)
which.min(reg01$bic)
coef(fit01,8)   # 8 variables selected

library(MASS)
fit02 = stepAIC(fit, direction="both")
summary(fit02)  # 11 variables selected; Adj. R2: 0.735 

##################################################
# Bayesian Model Averaging
##################################################
library(dplyr) 
library(BMS) 

# Move the dependent variable to the first column
Boston1 = Boston %>% select(medv, everything())
head(Boston1)

# mcmc is Markov Chain Monte Carlo
fit03 = bms(Boston1, burn=1000, iter=1e+05, g="BRIC", mprior="uniform", 
          nmodel=2000, mcmc="bd", user.int=F)
coef(fit03)
# rm, dis, ptratio, lstat, nox, rad, black, tax, zn, chas, crim (0.87), indus (0.05), age (0.04)

##################################################
# Non-linear model -- Random Forest model
##################################################
library(randomForest)
?randomForest
train = sample(1:nrow(Boston), nrow(Boston)/2)
boston.test=Boston[-train,"medv"]
set.seed(1)

# Bagging with 500 trees
bag.boston=randomForest(medv~.,data=Boston,subset=train,mtry=13,ntree=500)
bag.boston
yhat.bag = predict(bag.boston,newdata=Boston[-train,])
plot(yhat.bag, boston.test, ylim=c(0,50), xlim=c(0,50))
abline(0,1)
grid()
mean((yhat.bag-boston.test)^2)
importance(bag.boston)
varImpPlot(bag.boston)

# Random Forest
rf.boston=randomForest(medv~.,data=Boston,subset=train,mtry=4,importance=TRUE,ntree=500)
yhat.rf = predict(rf.boston,newdata=Boston[-train,])
plot(yhat.rf, boston.test, ylim=c(0,50), xlim=c(0,50))
abline(0,1)
grid()
mean((yhat.rf-boston.test)^2)
importance(rf.boston)
varImpPlot(rf.boston)

