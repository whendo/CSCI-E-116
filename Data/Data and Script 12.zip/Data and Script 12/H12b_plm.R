###########################################################################################
# H12b. Panel Data Forecast
# By William Yu, UCLA Anderson Forecast
# 4/16/2024
# https://www.jstatsoft.org/article/view/v027i02
# https://cran.r-project.org/web/packages/plm/plm.pdf
###########################################################################################
setwd("C:/Users/wiyu/documents/zip08/2024 Q4 Fall_Harvard/Data/")

library('plm')
##
## 10 Firms, Year 1935 to 1954
##
data("Grunfeld", package = "plm")
library(gplots)
plotmeans(inv ~ firm, main="Heterogeneity across firms", data=Grunfeld)
plotmeans(inv ~ year, main="Heterogeneity across years", data=Grunfeld)

# inv: real gross investment for firm i in year t
# value: real value of firm's outstanding shares
# capital: real value of the capital stock
ols = lm(inv ~ value + capital, data = Grunfeld)
summary(ols)

fe00 = plm(inv ~ value + capital, data = Grunfeld, model = "pooling")
summary(fe00)

# Firm fixed effect
fe01 = lm(inv ~ value + capital + factor(firm), data = Grunfeld)
summary(fe01)

# Firm fixed effect removing the intercept term
fe011 = lm(inv ~ 0 + value + capital + factor(firm), data = Grunfeld)
summary(fe011)

fe02 = plm(inv ~ value + capital, data = Grunfeld, index=c("firm", "year"), model = "within")
summary(fe02)

fixef(fe02)     # Display the firm fixed effects

pFtest(fe02, ols)  # fixed effect is a better choice

# Firm fixed effect + time fixed effect
fe03 = lm(inv ~ 0 + value + capital + factor(firm) + factor(year), data = Grunfeld)
summary(fe03)

# Firm fixed effect + time fixed effect
fe04 = plm(inv ~ value + capital, data = Grunfeld, model = "within", effect="twoways")
summary(fe04)

fixef(fe04, effect="time")

pFtest(fe04, fe02) # No difference

# Breusch-Godfrey/Wooldridge test for serial correlation in panel models
pbgtest(fe02)  # There is a strong serial correlation

# Breusch-Pagan test. Null hypothesis is homoskedasticity
library(lmtest)
bptest(inv ~ value + capital + factor(firm), data = Grunfeld, studentize=F)
# Presence of heteroskedasticity

# Heteroskedasticity consistent coefficients (Arellano)
coeftest(fe02, vcovHC(fe02, method = "arellano")) 

library(tseries)
Grunfeld.p = pdata.frame(Grunfeld, index = c("firm", "year"))

# Augmented Dickey-Fuller test
adf.test(Grunfeld.p$inv, k=2)   # p-value less than 0.05 --> no unit root

# AR1 + fixed effect
Grunfeld$inv_lag1 = lag(Grunfeld$inv, 1)  # Doesn't work

Grunfeld.p$inv_lag1 = lag(Grunfeld.p$inv, 1) 

fe05 = plm(inv ~ inv_lag1 + value + capital, data = Grunfeld.p, model = "within")
summary(fe05)

fe06 = plm(inv ~ lag(inv) + value + capital, data = Grunfeld, model = "within")
summary(fe06)

re02 = plm(inv ~ value + capital, data = Grunfeld.p, model = "random")
summary(re02)

re04 = plm(inv ~ value + capital, data = Grunfeld.p, model = "random", effect="twoways")
summary(re04)

pFtest(fe02, re02) # No difference
pFtest(fe04, re04) # No difference

# Generate 55 new observations of three firms used for prediction:
#  * firm 1 with years 1935:1964 (has out-of-sample years 1955:1964), 
#  * firm 2 with years 1935:1949 (all in sample),
#  * firm 11 with years 1935:1944 (firm 11 is out-of-sample)

set.seed(42L)
new.value2   = runif(55, min = min(Grunfeld$value),   max = max(Grunfeld$value))
new.capital2 = runif(55, min = min(Grunfeld$capital), max = max(Grunfeld$capital))

newdata = data.frame(firm = c(rep(1, 30), rep(2, 15), rep(11, 10)),
                     year = c(1935:(1935+29), 1935:(1935+14), 1935:(1935+9)),
                     value = new.value2, capital = new.capital2)
# Make pdata.frame
newdata.p = pdata.frame(newdata, index = c("firm", "year"))

## predict from fixed effect model with new data as pdata.frame
predict(fe02, newdata = newdata.p) # has NA values for the 11'th firm

## set na.fill = TRUE to have the weighted mean used to for fixed effects -> no NA values
predict(fe02, newdata = newdata.p, na.fill = TRUE)

# Prediction check: Firm 1 in 1964
-70.3 + 0.11*5227.6 + 0.31*1727.4  # (prediction: 1,040)
# Prediction check: Firm 2 in 1935
101.9 + 0.11*4619.1 + 0.31*1255.2  # (prediction: 999)

predict(fe05, newdata = newdata.p)

##
## Example
##
library(readxl)  
library(dplyr)
library(tidyverse)
wdi = data.frame(read_excel("W02d_wdi.xlsx"))     # World Development Indicators
# Get variables for life expectancy, total population, and fertility rate
wdi3v = wdi %>% subset(Indicator.Code %in% c("SP.DYN.LE00.IN","NY.GDP.PCAP.KD","SP.DYN.TFRT.IN"))
wdi3v = wdi3v[,-c(2,4)] # remove column 2 and 4

p = ncol(wdi3v) # find the number of column
wdi3v.long = gather(wdi3v,key="year",value="value", 3:p) # Name the key name "year" and value name "value"
wdi3v.long = wdi3v.long %>% mutate(year=gsub("X","", year))
wdi3vp = spread(wdi3v.long, Indicator.Name, value) 
colnames(wdi3vp)=c("country","year","fertility","gdppc","life")

wdi3vp$fertility_lag1 = stats::lag(wdi3vp$fertility, 1) # Not working
wdi3vp$fertility_lag1 = NULL

wdi3vp = pdata.frame(wdi3vp, index = c("country", "year"))

wdi3vp$fertility_lag1 = plm::lag(wdi3vp$fertility, 1) 
wdi3vp$gdppc_lag1 = plm::lag(wdi3vp$gdppc, 1) 
wdi3vp$life_lag1 = plm::lag(wdi3vp$life, 1) 

fe11 = plm(fertility ~ gdppc_lag1 + life_lag1, data = wdi3vp, model = "within", effect="twoways")
summary(fe11)  

fe12 = plm(fertility ~ fertility_lag1 + gdppc_lag1 + life_lag1, data = wdi3vp, model = "within", effect="twoways")
summary(fe12)  

# first-difference model
fe13 = plm(fertility ~ fertility_lag1 + gdppc_lag1 + life_lag1, data = wdi3vp, model = "fd")
summary(fe13)

pre_fe11 = data.frame(wdi3vp[,3], predict(fe11, newdata = wdi3vp, na.fill = TRUE))
pre_fe12 = data.frame(wdi3vp[,3], predict(fe12, newdata = wdi3vp, na.fill = TRUE))
pre_fe13 = data.frame(predict(fe13, newdata = wdi3vp))

##
## Dynamic Panel Model
##
install.packages('panelvar')
library('panelvar')

data(Cigar)
ex1_feols =
  pvarfeols(dependent_vars = c("log_sales", "log_price"),
            lags = 1,
            exog_vars = c("cpi"),
            transformation = "demean",
            data = Cigar,
            panel_identifier= c("state", "year"))
summary(ex1_feols)

predict(ex1_feols)
