######################################################################################################
# H12a. Hierarchical and Grouped Time Series
# By William Yu, UCLA Anderson Forecast
# 11/19/2024
# https://otexts.com/fpp2/hierarchical.html
###################################################################################################### 
library(fpp2)     
library(hts)
library(MASS)

##
## Generalized Least Squares (GLS) vs Ordinary Least Squares (OLS)
##

set.seed(0)
# Generate synthetic data
n = 100
x = seq(0, 10, length.out = n)
beta_0 = 5
beta_1 = 2

# Generate heteroscedastic errors (variance increases with x)
errors = rnorm(n, mean = 0, sd = 0.9 * x)
y = beta_0 + beta_1 * x + errors

# Adjust x to avoid division by zero
x_adjusted = x + 0.1
errors_adjusted = rnorm(n, mean = 0, sd = 0.5 * x_adjusted)
y_adjusted = beta_0 + beta_1 * x_adjusted + errors_adjusted

# OLS model
ols_model = lm(y_adjusted ~ x_adjusted)
summary(ols_model)

# GLS model with inverse-variance weights
weights = 1 / (0.5 * x_adjusted)^2
gls_model = lm(y_adjusted ~ x_adjusted, weights = weights)
summary(gls_model)

# Extract and compare the results
results = data.frame(
  Method = c("OLS", "GLS"),
  Intercept = c(coef(ols_model)[1], coef(gls_model)[1]),
  Slope = c(coef(ols_model)[2], coef(gls_model)[2]),
  Intercept_SE = c(summary(ols_model)$coefficients[1, 2], summary(gls_model)$coefficients[1, 2]),
  Slope_SE = c(summary(ols_model)$coefficients[2, 2], summary(gls_model)$coefficients[2, 2])
)

# Print results
print(results)

# Visualize the synthetic data and fitted lines
plot(x_adjusted, y_adjusted, main = "OLS vs GLS Fit", xlab = "x", ylab = "y", pch = 16, col = "grey")
abline(ols_model, col = "blue", lwd = 2, lty = 2) # OLS fit (dashed)
abline(gls_model, col = "red", lwd = 2)           # GLS fit (solid)
legend("topleft", legend = c("OLS", "GLS"), col = c("blue", "red"), lty = c(2, 1), lwd = 2)

##
## Problem for GLS: the covaraince matrix is not known
## Solution: Feasible Generalized Least Squares (FGLS) and Weighted Least Squares (WLS)
##

# Set seed for reproducibility
set.seed(123)

# Generate synthetic data with heteroscedasticity
n = 100
x = seq(1, 10, length.out = n)
beta_0 = 5
beta_1 = 2

# Generate errors with increasing variance as a function of x
errors = rnorm(n, mean = 0, sd = 0.9 * x)
y = beta_0 + beta_1 * x + errors

# Step 1: Fit an initial OLS model
ols_model = lm(y ~ x)
summary(ols_model)

# Step 2: Obtain residuals and estimate variance structure
residuals = residuals(ols_model)
fitted_values = fitted(ols_model)

# Step 3: Estimate weights based on residual variance
# We'll fit a model of squared residuals as a function of fitted values to estimate heteroscedasticity
variance_model = lm(residuals^2 ~ fitted_values)
predicted_variance = fitted(variance_model)

# Step 4: Calculate weights as the inverse of predicted variance
weights = abs(1 / predicted_variance)

# Step 5: Fit a GLS model using these weights
gls_model = lm(y ~ x, weights = weights)
summary(gls_model)

# Compare the OLS and GLS results
results = data.frame(
  Method = c("OLS", "GLS"),
  Intercept = c(coef(ols_model)[1], coef(gls_model)[1]),
  Slope = c(coef(ols_model)[2], coef(gls_model)[2]),
  Intercept_SE = c(summary(ols_model)$coefficients[1, 2], summary(gls_model)$coefficients[1, 2]),
  Slope_SE = c(summary(ols_model)$coefficients[2, 2], summary(gls_model)$coefficients[2, 2])
)

# Print results
print(results)

# Plot the original data with both OLS and GLS fits
plot(x, y, main = "OLS vs GLS Fit with Estimated Weights", xlab = "x", ylab = "y", pch = 16, col = "grey")
abline(ols_model, col = "blue", lwd = 2, lty = 2) # OLS fit (dashed)
abline(gls_model, col = "red", lwd = 2)           # GLS fit (solid)
legend("topleft", legend = c("OLS", "GLS"), col = c("blue", "red"), lty = c(2, 1), lwd = 2)


##
## Hierarchical Time Series
##
visnights = visnights

#The first three characters of each column name of visnights capture the categories 
# at the first level of the hierarchy (States). 
# The following five characters capture the bottom-level categories (Zones).
tourism.hts = hts(visnights, characters = c(3, 5)) 
tourism.hts %>% aggts(levels=0:1) %>%
  autoplot(facet=TRUE) +
  xlab("Year") + ylab("millions") + ggtitle("Visitor nights")

head(tourism.hts)

library(tidyverse)
cols = sample(scales::hue_pal(h=c(15,375),
                               c=100,l=65,h.start=0,direction = 1)(NCOL(visnights)))
as_tibble(visnights) %>%
  gather(Zone) %>%
  mutate(Date = rep(time(visnights), NCOL(visnights)),
         State = str_sub(Zone,1,3)) %>%
  ggplot(aes(x=Date, y=value, group=Zone, colour=Zone)) +
  geom_line() +
  facet_grid(State~., scales="free_y") +
  xlab("Year") + ylab("millions") +
  ggtitle("Visitor nights by Zone") +
  scale_colour_manual(values = cols)

##
## Grouped Time Series
##
prison = prison
prison.gts = gts(prison/1e3, characters = c(3,1,9),
                  gnames = c("State", "Gender", "Legal",
                             "State*Gender", "State*Legal",
                             "Gender*Legal"))

prison.gts %>% aggts(level=0:3) %>% autoplot()

p1 = prison.gts %>% aggts(level=0) %>%
  autoplot() + ggtitle("Australian prison population") +
  xlab("Year") + ylab("Total number of prisoners ('000)")
groups = aggts(prison.gts, level=1:3)
cols = sample(scales::hue_pal(h=c(15,375),
                               c=100,l=65,h.start=0,direction = 1)(NCOL(groups)))
p2 = as_tibble(groups) %>%
  gather(Series) %>%
  mutate(Date = rep(time(groups), NCOL(groups)),
         Group = str_extract(Series, "([A-Za-z ]*)")) %>%
  ggplot(aes(x=Date, y=value, group=Series, colour=Series)) +
  geom_line() +
  xlab("Year") + ylab("Number of prisoners ('000)") +
  scale_colour_manual(values = cols) +
  facet_grid(.~Group, scales="free_y") +
  scale_x_continuous(breaks=seq(2006,2016,by=2)) +
  theme(axis.text.x = element_text(angle = 90, hjust = 1))
gridExtra::grid.arrange(p1, p2, ncol=1)

p1 = autoplot(calls) +
  ylab("Call volume") + xlab("Weeks") +
  scale_x_continuous(breaks=seq(1,33,by=2))
p2 = autoplot(window(calls, end=4)) +
  ylab("Call volume") + xlab("Weeks") +
  scale_x_continuous(minor_breaks = seq(1,4,by=0.2))
gridExtra::grid.arrange(p1,p2)

##
## The Bottom-Up Approach
##
forecast(tourism.hts, method="bu", fmethod="arima")
forecast(prison.gts, method="bu", fmethod="arima")
forecast(prison.gts, method="bu", fmethod="ets")

# ETS (Error, Trend, Seasonal) Model / Exponential Smoothing State Space Model

##
## The Top-Down Approach
##
forecast(tourism.hts, method="tdgsa", fmethod="arima")

##
## The Optimal Reconciliation Approach
##
prisonfc = forecast(prison.gts)
fcsts = aggts(prisonfc, levels=0:3)
groups = aggts(prison.gts, levels=0:3)
autoplot(fcsts) + autolayer(groups)

prisonfc = ts(rbind(groups, fcsts),
               start=start(groups), frequency=4)
p1 = autoplot(prisonfc[,"Total"]) +
  ggtitle("Australian prison population") +
  xlab("Year") + ylab("Total number of prisoners ('000)") +
  geom_vline(xintercept=2017)
cols = sample(scales::hue_pal(h=c(15,375),
                               c=100,l=65,h.start=0,direction = 1)(NCOL(groups)))
p2 = as_tibble(prisonfc[,-1]) %>%
  gather(Series) %>%
  mutate(Date = rep(time(prisonfc), NCOL(prisonfc)-1),
         Group = str_extract(Series, "([A-Za-z ]*)")) %>%
  ggplot(aes(x=Date, y=value, group=Series, colour=Series)) +
  geom_line() +
  xlab("Year") + ylab("Number of prisoners ('000)") +
  scale_colour_manual(values = cols) +
  facet_grid(. ~ Group, scales="free_y") +
  scale_x_continuous(breaks=seq(2006,2018,by=2)) +
  theme(axis.text.x = element_text(angle=90, hjust=1)) +
  geom_vline(xintercept=2017)
gridExtra::grid.arrange(p1, p2, ncol=1)