######################################################################################################
# H11: Cointegration
# By William Yu, UCLA Anderson Forecast
# 4/9/2024
# Reference: https://www.econometrics-with-r.org/16.3-cointegration.html
###################################################################################################### 
library(AER)
library(dynlm)
library(quantmod)
library(vars)
library(fGARCH)
library(scales)
library(urca)
library(lubridate)

getSymbols("DGS10", src="FRED") 
getSymbols("DTB3", src="FRED") 
TB10YS = apply.monthly(DGS10, mean, na.rm=T)
TB3MS = apply.monthly(DTB3['1962/'], mean, na.rm=T)
TSpread = TB10YS - TB3MS

acf(TB10YS,lag.max=60)
acf(TB3MS,lag.max=60)
acf(TSpread,lag.max=60)

plot(merge(as.zoo(TB10YS), as.zoo(TB3MS)), 
     plot.type = "single", 
     lty = c(2, 1),
     lwd = 2,
     xlab = "Date",
     ylab = "Percent per annum",
     ylim = c(-5, 17),
     main = "Interest Rates")

# add the term spread series
lines(as.zoo(TSpread), 
      col = "steelblue",
      lwd = 2,
      xlab = "Date",
      ylab = "Percent per annum",
      main = "Term Spread")

# add horizontal line add 0
abline(0, 0)

# add a legend
legend("topright", 
       legend = c("TB3MS", "TB10YS", "Term Spread"),
       col = c("black", "black", "steelblue"),
       lwd = c(2, 2, 2),
       lty = c(2, 1, 1))

# test for nonstationarity of 3-month treasury bills using ADF test
ur.df(TB3MS, lags = 6, selectlags = "AIC", type = "drift")
# fail to reject the hull (nonstationary) so it is nonstationary

# test for nonstationarity of 10-year treasury bonds using ADF test
ur.df(TB10YS, lags = 6, selectlags = "AIC", type = "drift")
# fail to reject the hull (nonstationary) so it is nonstationary

# test for nonstationarity of 3-month treasury bills using DF-GLS test
ur.ers(TB3MS, lag.max = 6, model = "constant")

# test for nonstationarity of 10-year treasury bonds using DF-GLS test
ur.ers(TB10YS, lag.max = 6, model = "constant")

# Fail to reject the null hypothesis that the variable is nonstaintionary.
# Engle-Granger ADF Statistics: 10% -3.12, 5% -3.41, 1% -3.96

# test if term spread is stationairy (cointegration of interest rates) using ADF
ur.df((TB10YS - TB3MS), lags = 6, selectlags = "AIC", type = "drift")

# test if term spread is stationairy (cointegration of interest rates) using DF-GLS test
ur.ers((TB10YS - TB3MS), lag.max = 6, model = "constant")

# Both tests reject the hypothesis of nonstationarity of the term spread series at 
# the 5% level of significance, which is evidence in favor of the hypothesis that
# the term spread is stationary, implying cointegration of long- and short-term 
# interest rates.

##
## Vector Error Correction Model (VECM)
##
VECM_ECT = TB10YS - TB3MS
colnames(VECM_ECT)=c("VECM_ECT")
colnames(TB10YS)=c("TB10YS")
colnames(TB3MS)=c("TB3MS")

vecm_ect=ts(VECM_ECT,frequency=12, start=c(1962,1))
tb10ys=ts(TB10YS,frequency=12, start=c(1962,1))
tb3ms=ts(TB3MS,frequency=12, start=c(1962,1))

# Not a good model because both series are nonstationary
eq00 = dynlm(tb10ys ~ tb3ms) 
coeftest(eq00, vcov. = NeweyWest(eq00, prewhite = F, adjust = T))

# estimate both equations of the VECM using 'dynlm()'
eq01 = dynlm(d(tb10ys) ~ L(d(tb3ms), 1:3) + L(d(tb10ys), 1:3) + L(vecm_ect,1))
eq02 = dynlm(d(tb3ms) ~ L(d(tb3ms), 1:3) + L(d(tb10ys), 1:3) + L(vecm_ect,1))

# coefficient summaries using HAC standard errors
coeftest(eq01, vcov. = NeweyWest(eq01, prewhite = F, adjust = T))
coeftest(eq02, vcov. = NeweyWest(eq02, prewhite = F, adjust = T))

##
## Case study: Are Bitcoin and Etherum prices cointegrated?
##

getSymbols("CBBTCUSD", src="FRED") 
getSymbols("CBETHUSD", src="FRED") 

bitcoin = apply.weekly(CBBTCUSD['2016-05-18/'], mean, na.rm=T)
ether = apply.weekly(CBETHUSD, mean, na.rm=T)

week("2016-05-22") # check the week # for the beginning of the series

bitcoin = ts(bitcoin,frequency=52, start=c(2016,21))
ether = ts(ether,frequency=52, start=c(2016, 21))

bitcoin = log(bitcoin)
ether = log(ether)

fit01 = dynlm(bitcoin ~ ether)
summary(fit01)

# compute the residuals (which is the error correction term: Y-BX)
z_hat = resid(fit01)

# compute the ADF test statistic
ur.df(z_hat, lags = 6, type = "none", selectlags = "AIC")
# test statistic: -2.6
# Fail to reject the null hypothesis (series is nonstationary). 
# That is the error correction term is nonstationary.
# Bitcoin and Etherm has no cointegration. 
acf(z_hat,lag.max=60)

eq01 = dynlm(d(bitcoin) ~ L(d(bitcoin), 1) + L(d(ether), 1) + L(z_hat,1))
eq02 = dynlm(d(ether) ~ L(d(bitcoin), 1) + L(d(ether), 1) + L(z_hat,1))

# coefficient summaries using HAC standard errors
coeftest(eq01, vcov. = NeweyWest(eq01, prewhite = F, adjust = T))
coeftest(eq02, vcov. = NeweyWest(eq02, prewhite = F, adjust = T))
